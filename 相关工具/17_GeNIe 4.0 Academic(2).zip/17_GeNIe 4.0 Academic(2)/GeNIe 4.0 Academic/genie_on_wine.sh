arr=(api*.dll)
dx="vcruntime140=n;ucrtbase=n"
for ((i=0; i<${#arr[@]}; i++)); do dx="$dx;${arr[$i]}=n"; done
export WINEDLLOVERRIDES=$dx
wine genie.exe
