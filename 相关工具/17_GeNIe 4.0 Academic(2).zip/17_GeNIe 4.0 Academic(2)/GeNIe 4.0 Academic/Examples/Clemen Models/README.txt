This directory contains decision models extracted from
the textbook by Robert T. Clemen, Making Hard Decisions:
An Introduction to Decision Analysis, Second Edition.
Duxbury Press, 1996.  The models are extracted with
permission of Duxbury Press and are meant to be an aid
to those teachers who choose to use GeNIe in combination
with the textbook.

To obtain a copy of GeNIe (free for educational research
and teaching), please visit:

  https://www.bayesfusion.com/

For "Making Hard Decisions," visit your nearest bookstore
or contact Duxbury Press.


Since the models included in this file are accessible by
both students and teachers, they cover the contents of the
chapters but none of the exercises.  Exercises are,
however, not hard to model using GeNIe.

GeNIe implements Bayesian networks and influence diagrams.
In several cases, we reinterpreted probability tree and
decision tree models inclueded in the textbook as Bayesian
networks and influence diagrams.  In one case (Table 15.6),
we implemented as a hierarchical influence diagram a
multi-attribute utility function, represented originally
by a spreadsheet table.

The few textbook examples that rely on continuous nodes
and multiplicative forms of multi-attribute utility
function have not been currently implemented.

Teachers using GeNIe and the models included in this ZIP
file are encouraged to contact BayesFusion, LLC, in case
they encounter any problems or have any suggestions.
We hope that GeNIe will grant you your three wishes and
will prove a useful teaching and learning aid.

BayesaFusion, LLC
https://www.bayesfusion.com/
support@bayesfusion.com