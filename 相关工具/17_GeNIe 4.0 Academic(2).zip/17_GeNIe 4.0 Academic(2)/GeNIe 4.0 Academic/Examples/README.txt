This directory contains a sizable library of example models, data sets,
and networks used in GeNIe manual.  The directory has several
sub-directories, listed alphabetically below:

Clemen Models:
models extracted from the textbook by Robert T. Clemen, "Making
Hard Decisions: An Introduction to Decision Analysis," Second Edition,
Duxbury Press, 1996

Discrete Bayesian Networks:
the most popular type of Bayesian network models, which is those
consisting of discrete variables

Dynamic Bayesian Networks:
discrete-time models used for modeling dynamic systems

Hybrid Bayesian Networks:
models consisting of continuous variables specified by means of
equations and mixtures of continuous and discrete variables

Influence Diagrams:
influence diagram models

Learning:
data sets and other auxiliary files useful in learning
Bayesian networks and causal discovery

Models from the Manual:
a collection of models and other auxiliary files used in GeNIe manual